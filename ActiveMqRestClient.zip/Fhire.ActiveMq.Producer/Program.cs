﻿using Apache.NMS;
using Apache.NMS.Util;
using System;

namespace Fhire.ActiveMq.Producer
{
    public class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                string text = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(text)) return;
                SendNewMessageQueue(text);
            }
        }

        private static void SendNewMessageQueue(string text)
        {
            string queueName = "FhirQueue";

            Console.WriteLine($"Adding message to queue topic: {queueName}");

            string brokerUri = $"activemq:tcp://localhost:61617";  // Default port
            NMSConnectionFactory factory = new NMSConnectionFactory(brokerUri);
            using (IConnection connection = factory.CreateConnection())
            {
              
                connection.Start();

                using (ISession session = connection.CreateSession(AcknowledgementMode.AutoAcknowledge))
                using (IDestination dest = session.GetQueue(queueName))
                using (IMessageProducer producer = session.CreateProducer(dest))
                {
                    producer.DeliveryMode = MsgDeliveryMode.Persistent;
                    producer.Send(session.CreateTextMessage(text));
                    Console.WriteLine($"Sent {text} messages");

                }
            }
        }
    }
}