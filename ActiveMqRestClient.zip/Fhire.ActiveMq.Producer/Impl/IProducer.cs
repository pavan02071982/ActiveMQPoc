﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fhire.ActiveMq.Producer.Impl
{
    public interface IProducer
    {
        string PutIntoMessageQueueAsynchronously(string request, string queueName);
    }
}
