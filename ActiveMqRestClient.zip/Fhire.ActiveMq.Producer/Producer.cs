﻿using Apache.NMS;
using Fhire.ActiveMq.Producer.Impl;
using System;

namespace Fhire.ActiveMq.Producer
{
    public class Producer : IProducer
    {
        private const string DeliveryNote = "Your message has been acknwoledged & delivered with session ID :";

        public string PutIntoMessageQueueAsynchronously(string request, string queueName)
        {
            //string brokerUri = $"activemq:tcp://localhost:61617";  // Default port
            // Failover cases
            string brokerUri = $"failover:(tcp://localhost:61617,tcp://localhost:61618,tcp://localhost:61619)?randomize=true";

            IConnectionFactory factory = new Apache.NMS.ActiveMQ.ConnectionFactory(brokerUri);
            //NMSConnectionFactory factory = new NMSConnectionFactory(brokerUri);
            using (IConnection connection = factory.CreateConnection())
            {
                connection.Start();
                using (ISession session = connection.CreateSession(AcknowledgementMode.AutoAcknowledge))
                using (IDestination dest = session.GetQueue(queueName))
                using (IMessageProducer producer = session.CreateProducer(dest))
                {
                    producer.DeliveryMode = MsgDeliveryMode.Persistent;
                    producer.TimeToLive = TimeSpan.FromSeconds(10);
                    producer.Send(session.CreateTextMessage(request));
                    var sessionId = ((Apache.NMS.ActiveMQ.Session)session).SessionId.ConnectionId;
                    return DeliveryNote + sessionId;
                }

            }
        }
    }
}
