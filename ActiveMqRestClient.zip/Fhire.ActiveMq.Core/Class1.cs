﻿using System;

namespace Fhire.ActiveMq.Core
{
    public class Class1
    {
    }
}
