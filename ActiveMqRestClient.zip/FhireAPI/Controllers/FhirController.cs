﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using Apache.NMS;
using Apache.NMS.ActiveMQ;
using Fhire.ActiveMq.Producer;
using Fhire.ActiveMq.Producer.Impl;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Spring.Messaging.Nms.Support.Destinations;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace FhireAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FhirController : ControllerBase
    {
        private IConfiguration _configuration;

        private readonly IProducer Producer;
        public FhirController(IConfiguration configuration)
        {
            _configuration = configuration;
            Producer = new Producer();
        }
        // GET: api/<FhirRestAPIController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<FhirRestAPIController>/5
        [HttpGet("{id}")]
        public string Get(Guid id)
        {
            var request = new FhirRequest { FhirAction = "GET", PatientId = id, MessageeBody = "" };
            var requestJson = Newtonsoft.Json.JsonConvert.SerializeObject(request).ToString();
            return Producer.PutIntoMessageQueueAsynchronously(requestJson, "FhirQueue");
        }

        // POST api/<FhirRestAPIController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<FhirRestAPIController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<FhirRestAPIController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        private static void PutIntoMessageQueueAsynchronously(string request)
        {
            string queueName = "FhirQueue";
            string brokerUri = $"activemq:tcp://localhost:61622";  // Default port
            NMSConnectionFactory factory = new NMSConnectionFactory(brokerUri);
            using (IConnection connection = factory.CreateConnection())
            {
                connection.Start();
                using (ISession session = connection.CreateSession(AcknowledgementMode.AutoAcknowledge))
                using (IDestination dest = session.GetQueue(queueName))
                using (IMessageProducer producer = session.CreateProducer(dest))
                {
                    producer.DeliveryMode = MsgDeliveryMode.Persistent;
                    producer.Send(session.CreateTextMessage(request));
                }
            }
        }

        private void PutIntoMessageQueueSynchronously(string request)
        {
            ConnectionFactory connectionFactory = new ConnectionFactory("activemq:tcp://localhost:61617");
            try
            {
                using (IConnection connection = connectionFactory.CreateConnection())
                {
                    using (ISession session = connection.CreateSession())
                    {
                        ITemporaryQueue queue = session.CreateTemporaryQueue();
                        using (IMessageConsumer consumer = session.CreateConsumer(queue))
                        {
                            ITextMessage message = session.CreateTextMessage(request);
                            message.NMSReplyTo = queue;
                            string correlationId = Guid.NewGuid().ToString();
                            message.NMSCorrelationID = correlationId;
                            using (IMessageProducer producer = session.CreateProducer())
                            {
                                NmsDestinationAccessor destinationResolver = new NmsDestinationAccessor();
                                IDestination destination = destinationResolver.ResolveDestinationName(session, "FhirQueue");
                                producer.Send(destination, message);
                            }
                            IMessage response = consumer.Receive(TimeSpan.FromSeconds(60));
                            ITextMessage textMessage = response as ITextMessage;
                            Console.WriteLine(textMessage.Text);
                        }

                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
    public class FhirRequest
    {
        public string FhirAction { get; set; }
        public dynamic MessageeBody { get; set; }
        public Guid PatientId { get; set; }
    }
}
