﻿using Apache.NMS;
using Fhire.ActiveMq.Producer;
using FhireAPI.Controllers;
using Hl7.Fhir.Model;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography.Xml;
using Fhire.ActiveMq.Producer.Impl;

namespace Fhire.ActiveMq.Subscriber
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Waiting for messages");

            // Read all messages off the queue
            while (ReadNextMessageQueue())
            {
                Console.WriteLine("Successfully read message");
            }

            Console.WriteLine("Finished");
        }

        static bool ReadNextMessageQueue()
        {
            string queueName = "FhirRequestQueue";

            //string brokerUri = $"activemq:tcp://localhost:61617";  // Default port
            // Failover cases
            string brokerUri = $"failover:(tcp://localhost:61617,tcp://localhost:61618,tcp://localhost:61619)?randomize=true";

            IConnectionFactory factory = new Apache.NMS.ActiveMQ.ConnectionFactory(brokerUri);
            //NMSConnectionFactory factory = new NMSConnectionFactory(brokerUri);
           
            using (IConnection connection = factory.CreateConnection())
            {
                connection.Start();
                using (ISession session = connection.CreateSession(AcknowledgementMode.AutoAcknowledge))
                using (IDestination dest = session.GetQueue(queueName))
                using (IMessageConsumer consumer = session.CreateConsumer(dest))
                {
                    IMessage msg = consumer.Receive();
                    if (msg is ITextMessage)
                    {
                        ITextMessage txtMsg = msg as ITextMessage;
                        if (!string.IsNullOrEmpty(txtMsg.Text))
                            CallFhirApi(txtMsg);

                        Console.WriteLine($"Received message: {txtMsg.Text}");

                        return true;
                    }
                    else
                    {
                        //Console.WriteLine("Unexpected message type: " + msg.GetType().Name);
                    }
                }
            }

            return false;
        }

        private static void CallFhirApi(ITextMessage txtMsg)
        {
            var requestJson = (FhirRequest)JsonConvert.DeserializeObject(txtMsg.Text, typeof(FhirRequest));
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://vonk.fire.ly/Patient/" + requestJson.PatientId);

            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/fhir+json"));

            // List data response.
            HttpResponseMessage response = client.GetAsync("http://vonk.fire.ly/Patient/" + requestJson.PatientId).Result;  // Blocking call! Program will wait here until a response is received or a timeout occurs.
            if (response.IsSuccessStatusCode)
            {
                // Parse the response body.
                var dataObjects = response.Content.ReadAsStringAsync().Result;  //Make sure to add a reference to System.Net.Http.Formatting.dll
                var producer = new Producer.Producer();
                producer.PutIntoMessageQueueAsynchronously(dataObjects, "ProcessedQueue");

            }
            else
            {
                Console.WriteLine("{0} ({1})", (int)response.StatusCode, response.ReasonPhrase);
            }

            //Make any other calls using HttpClient here.

            //Dispose once all HttpClient calls are complete. This is not necessary if the containing object will be disposed of; for example in this case the HttpClient instance will be disposed automatically when the application terminates so the following call is superfluous.
            client.Dispose();
        }
    }
}