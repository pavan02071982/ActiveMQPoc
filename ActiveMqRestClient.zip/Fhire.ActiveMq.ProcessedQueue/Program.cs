﻿using Apache.NMS;
using System;

namespace Fhire.ActiveMq.ProcessedQueue
{
    class Program
    {
       static void Main(string[] args)
        {
            Console.WriteLine("Waiting for messages");

            // Read all messages off the queue
            while (ReadNextMessageQueue())
            {
                Console.WriteLine("Successfully read message");
            }

            Console.WriteLine("Finished");
        }

        static bool ReadNextMessageQueue()
        {
            string queueName = "FhirProcessedQueue";

            //string brokerUri = $"activemq:tcp://localhost:61617";  // Default port
            // Failover cases
            string brokerUri = $"failover:(tcp://localhost:61617,tcp://localhost:61618,tcp://localhost:61619)?randomize=true";

            IConnectionFactory factory = new Apache.NMS.ActiveMQ.ConnectionFactory(brokerUri);

            using (IConnection connection = factory.CreateConnection())
            {
                connection.Start();
                using (ISession session = connection.CreateSession(AcknowledgementMode.AutoAcknowledge))
                using (IDestination dest = session.GetQueue(queueName))
                using (IMessageConsumer consumer = session.CreateConsumer(dest))
                {
                    IMessage msg = consumer.Receive();
                    if (msg is ITextMessage)
                    {
                        ITextMessage txtMsg = msg as ITextMessage;
                        Console.WriteLine($"Received message: {txtMsg.Text}");

                        return true;
                    }
                    else
                    {
                        //Console.WriteLine("Unexpected message type: " + msg.GetType().Name);
                    }
                }
            }

            return false;
        }
    }
}
