﻿using System;

namespace Fhire.Business
{
    public class Class1
    {
    }
}
